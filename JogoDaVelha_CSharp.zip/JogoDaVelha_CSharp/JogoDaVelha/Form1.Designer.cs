﻿namespace Tictactoe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cell1 = new System.Windows.Forms.Button();
            this.cell2 = new System.Windows.Forms.Button();
            this.cell3 = new System.Windows.Forms.Button();
            this.cell6 = new System.Windows.Forms.Button();
            this.cell5 = new System.Windows.Forms.Button();
            this.cell4 = new System.Windows.Forms.Button();
            this.cell9 = new System.Windows.Forms.Button();
            this.cell8 = new System.Windows.Forms.Button();
            this.cell7 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtO = new System.Windows.Forms.Label();
            this.txtX = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnResetar = new System.Windows.Forms.Button();
            this.txtTurn = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cell1
            // 
            this.cell1.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell1.Location = new System.Drawing.Point(18, 38);
            this.cell1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell1.Name = "cell1";
            this.cell1.Size = new System.Drawing.Size(122, 111);
            this.cell1.TabIndex = 0;
            this.cell1.UseVisualStyleBackColor = true;
            this.cell1.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell2
            // 
            this.cell2.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell2.Location = new System.Drawing.Point(148, 38);
            this.cell2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell2.Name = "cell2";
            this.cell2.Size = new System.Drawing.Size(122, 111);
            this.cell2.TabIndex = 1;
            this.cell2.UseVisualStyleBackColor = true;
            this.cell2.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell3
            // 
            this.cell3.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell3.Location = new System.Drawing.Point(279, 38);
            this.cell3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell3.Name = "cell3";
            this.cell3.Size = new System.Drawing.Size(122, 111);
            this.cell3.TabIndex = 2;
            this.cell3.UseVisualStyleBackColor = true;
            this.cell3.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell6
            // 
            this.cell6.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell6.Location = new System.Drawing.Point(279, 158);
            this.cell6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell6.Name = "cell6";
            this.cell6.Size = new System.Drawing.Size(122, 111);
            this.cell6.TabIndex = 5;
            this.cell6.UseVisualStyleBackColor = true;
            this.cell6.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell5
            // 
            this.cell5.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell5.Location = new System.Drawing.Point(148, 158);
            this.cell5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell5.Name = "cell5";
            this.cell5.Size = new System.Drawing.Size(122, 111);
            this.cell5.TabIndex = 4;
            this.cell5.UseVisualStyleBackColor = true;
            this.cell5.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell4
            // 
            this.cell4.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell4.Location = new System.Drawing.Point(18, 158);
            this.cell4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell4.Name = "cell4";
            this.cell4.Size = new System.Drawing.Size(122, 111);
            this.cell4.TabIndex = 3;
            this.cell4.UseVisualStyleBackColor = true;
            this.cell4.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell9
            // 
            this.cell9.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell9.Location = new System.Drawing.Point(279, 278);
            this.cell9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell9.Name = "cell9";
            this.cell9.Size = new System.Drawing.Size(122, 111);
            this.cell9.TabIndex = 8;
            this.cell9.UseVisualStyleBackColor = true;
            this.cell9.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell8
            // 
            this.cell8.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell8.Location = new System.Drawing.Point(148, 278);
            this.cell8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell8.Name = "cell8";
            this.cell8.Size = new System.Drawing.Size(122, 111);
            this.cell8.TabIndex = 7;
            this.cell8.UseVisualStyleBackColor = true;
            this.cell8.Click += new System.EventHandler(this.cell1_Click);
            // 
            // cell7
            // 
            this.cell7.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cell7.Location = new System.Drawing.Point(18, 278);
            this.cell7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cell7.Name = "cell7";
            this.cell7.Size = new System.Drawing.Size(122, 111);
            this.cell7.TabIndex = 6;
            this.cell7.UseVisualStyleBackColor = true;
            this.cell7.Click += new System.EventHandler(this.cell1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtO);
            this.groupBox1.Controls.Add(this.txtX);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(18, 398);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(204, 89);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PLACAR";
            // 
            // txtO
            // 
            this.txtO.AutoSize = true;
            this.txtO.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtO.ForeColor = System.Drawing.Color.Maroon;
            this.txtO.Location = new System.Drawing.Point(114, 55);
            this.txtO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtO.Name = "txtO";
            this.txtO.Size = new System.Drawing.Size(17, 18);
            this.txtO.TabIndex = 16;
            this.txtO.Text = "0";
            // 
            // txtX
            // 
            this.txtX.AutoSize = true;
            this.txtX.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtX.ForeColor = System.Drawing.Color.Blue;
            this.txtX.Location = new System.Drawing.Point(114, 24);
            this.txtX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(17, 18);
            this.txtX.TabIndex = 15;
            this.txtX.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Jogador O:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Jogador X:";
            // 
            // btnResetar
            // 
            this.btnResetar.Location = new System.Drawing.Point(231, 440);
            this.btnResetar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnResetar.Name = "btnResetar";
            this.btnResetar.Size = new System.Drawing.Size(170, 48);
            this.btnResetar.TabIndex = 14;
            this.btnResetar.Text = "&Resetar";
            this.btnResetar.UseVisualStyleBackColor = true;
            this.btnResetar.Click += new System.EventHandler(this.btnResetar_Click);
            // 
            // txtTurn
            // 
            this.txtTurn.AutoSize = true;
            this.txtTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTurn.ForeColor = System.Drawing.Color.Black;
            this.txtTurn.Location = new System.Drawing.Point(266, 408);
            this.txtTurn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTurn.Name = "txtTurn";
            this.txtTurn.Size = new System.Drawing.Size(70, 16);
            this.txtTurn.TabIndex = 15;
            this.txtTurn.Text = "O Jogou!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(408, 494);
            this.Controls.Add(this.txtTurn);
            this.Controls.Add(this.btnResetar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cell9);
            this.Controls.Add(this.cell8);
            this.Controls.Add(this.cell7);
            this.Controls.Add(this.cell6);
            this.Controls.Add(this.cell5);
            this.Controls.Add(this.cell4);
            this.Controls.Add(this.cell3);
            this.Controls.Add(this.cell2);
            this.Controls.Add(this.cell1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jogo da Velha";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cell1;
        private System.Windows.Forms.Button cell2;
        private System.Windows.Forms.Button cell3;
        private System.Windows.Forms.Button cell6;
        private System.Windows.Forms.Button cell5;
        private System.Windows.Forms.Button cell4;
        private System.Windows.Forms.Button cell9;
        private System.Windows.Forms.Button cell8;
        private System.Windows.Forms.Button cell7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label txtO;
        private System.Windows.Forms.Label txtX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnResetar;
        private System.Windows.Forms.Label txtTurn;
    }
}

